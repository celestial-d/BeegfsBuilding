#ifndef OPEN_RANDOM_H_
#define OPEN_RANDOM_H_

#include <common/Common.h>


extern int Random_getNextInt(void);
extern int Random_getNextInRange(int min, int max);

#endif /* OPEN_RANDOM_H_ */
