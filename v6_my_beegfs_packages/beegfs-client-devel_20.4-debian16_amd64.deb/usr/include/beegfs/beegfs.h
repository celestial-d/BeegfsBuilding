#ifndef __BEEGFS_H__
#define __BEEGFS_H__

#include <beegfs/beegfs_ioctl.h>

#endif /* __BEEGFS_H__ */
